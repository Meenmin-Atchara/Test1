<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <title>Photo Gallery</title>

</head>
<body>

<div class="jumbotron text-center">
  <h2>Photo Gallery</h2>
  <br>
  <a href="add_album.php" class="btn btn-primary" role="button">Add Album.</a>
  <a href="add_gallery.php" class="btn btn-info" role="button">Add Gallery.</a>

</div>
  
<div class="container">
  <div class="row">

      <div class="col-sm-4">
        <h3></h3>
        
      </div>

      <div class="col-sm-4">
        <h3>Create Album</h3>
    <form name="form1" method="post" action="save_album.php" enctype="multipart/form-data">
				Album Name : 
        <input type="text" name="txtAlbumName" id="txtAlbumName" maxlength="100"style="width: 130px; margin-left:5px;"><br><br>
        <input type="file" name="filAlbumShot" id="filAlbumShot" maxlength="100"><br>
			  <input  class="btn btn-info" type="submit" name="insert" id="insert" value="Insert">
		</form>
      </div>

      <div class="col-sm-4">
        <h3></h3>        
        
      </div>

  </div>
</div>

</body>
</html>
