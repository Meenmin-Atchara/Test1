<?php
// $servername = "192.168.70.36";
// $username = "meenmin";
// $password = "meenmin";
// $dbname = "phpgallery";

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "phpgallery";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";

?>