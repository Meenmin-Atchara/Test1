<html>
<head>
<title>Photo Gallery</title>
</head>
<body>

<?php
$conn = mysqli_connect("localhost", "root", "", "phpgallery");  
 if(isset($_GET["AlbumID"]))  
 {  


    // Select Old File (Album)

    $sql = "SELECT * FROM album WHERE AlbumID = '".$_GET["AlbumID"]."' ";
    $result = mysqli_query($conn, $sql); 


    //*** Delete Files (Album) ***//      
    @unlink($objResult["AlbumShot"]);
    
    //*** Delete Rows  (Album)***//
    $sql = " DELETE FROM album WHERE AlbumID = '".$_GET["AlbumID"]."' ";
    $result = mysql_query($conn, $sql);   
    

    //*** Loop Delete Gallery ***//
    $sql2 = "SELECT * FROM gallery WHERE AlbumID = '".$_GET["AlbumID"]."' ORDER BY GalleryID ASC ";
    $result2 = mysql_query($sql2) ;
    while($result2 = mysql_fetch_array($result2))
    {
      //*** Delete Files (Gallery) ***//      
      @unlink($result2["GalleryShot"]);
    }

    //*** Delete All Rows  (Gallery)***//
    $sql = " DELETE FROM gallery WHERE AlbumID = '".$_GET["AlbumID"]."' ";
    $result = mysql_query($conn, $sql);   

 



      if(mysqli_query($conn, $sql))  
      {  
      	echo "<script type='text/javascript'>";
		    echo"alert('Record deleted successfully');";
        echo"window.location = 'view_album.php';";
		    echo "</script>";
        // echo '<script>alert("Image Inserted into Database")</script>';  

      }  else{
      		echo "Error: " . $sql . "<br>" . mysqli_error($conn);

      }
 }  

	$conn->close();
	
		
?>


</body>
</html>