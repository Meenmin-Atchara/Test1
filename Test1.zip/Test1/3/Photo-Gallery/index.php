<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <title>Photo Gallery</title>

</head>
<body>

<div class="jumbotron text-center">
  <h2>Photo Gallery</h2>
  <br>
  <a href="add_album.php" class="btn btn-primary" role="button">Add Album.</a>
  <a href="add_gallery.php" class="btn btn-info" role="button">Add Gallery.</a>

</div>
  
<div class="container">
  <div class="row">

      <div class="col-sm-2">
        <h3></h3>
        
      </div>

      <div class="col-sm-8" style="margin-bottom: 55px;">
        <h3>All Albums.</h3>


            <?php  
                $conn = mysqli_connect("localhost", "root", "", "phpgallery");
                $sql  = "SELECT * FROM album ORDER BY AlbumID DESC";
                $result = mysqli_query($conn, $sql); 
                $intRows = 0; 
                while($row = mysqli_fetch_array($result))  
                {  
                    echo "<td>"; 
                    $intRows++;
                echo '  
                    <tr>   
                      <td>  
                        <a href=show_album.php?AlbumID='.$row["AlbumID"].'>
                          <img src="data:image/jpeg;base64,'.base64_encode($row['AlbumShot'] ).'" height="200" width="200" class="img-thumnail" />
                        </a> 

                      </td>  
                    </tr>  
                '; 
                    echo"</td>";
                    if(($intRows)%3==0)
                    {
                      echo"</tr>";
                    }
                }  
            ?>  

      </div>

      <div class="col-sm-2">
        <h3></h3>        
        
      </div>

  </div>
</div>

</body>
</html>

<script>  
 $(document).ready(function(){  
      $('#insert').click(function(){  
           var image_name = $('#filAlbumShot').val();  
           if(image_name == '')  
           {  
                alert("Please Select Image");  
                return false;  
           }  
           else  
           {  
                var extension = $('#filAlbumShot').val().split('.').pop().toLowerCase();  
                if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)  
                {  
                     alert('Invalid Image File');  
                     $('#filAlbumShot').val('');  
                     return false;  
                }  
           }  
      });  
 });  
 </script>  