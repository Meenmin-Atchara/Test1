<html>
<head>
<title>Photo Gallery</title>
</head>
<body>

<?php
$conn = mysqli_connect("localhost", "root", "", "phpgallery");  
 if(isset($_POST["insert"]))  
 {  
    $file = addslashes(file_get_contents($_FILES["filAlbumShot"]["tmp_name"]));  
    $sql = "INSERT INTO album (AlbumName,AlbumShot) VALUES ('".$_POST["txtAlbumName"]."','$file')";  

      if(mysqli_query($conn, $sql))  
      {  
      	echo "<script type='text/javascript'>";
		echo"alert('Image Inserted into Database');";
	    echo"window.location = 'index.php';";
		echo "</script>";
        // echo '<script>alert("Image Inserted into Database")</script>';  

      }  else{
      		echo "Error: " . $sql . "<br>" . mysqli_error($conn);

      }
 }  

	$conn->close();
	
		
?>


</body>
</html>