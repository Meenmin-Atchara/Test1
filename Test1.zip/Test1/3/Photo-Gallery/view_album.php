<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <title>Photo Gallery</title>

</head>
<body>

<div class="jumbotron text-center">
  <h2>Photo Gallery</h2>
  <br>
  <a href="add_album.php" class="btn btn-primary" role="button">Add Album.</a>
  <a href="add_gallery.php" class="btn btn-info" role="button">Add Gallery.</a>

</div>
  
<div class="container">
  <div class="row">

    <div class="col-sm-3">
        <h3></h3>
        
    </div>

    <div class="col-sm-6" style="margin-bottom: 55px;">
        <h3>All Albums.</h3>

			<?php 

			    $conn = mysqli_connect("localhost", "root", "", "phpgallery");
			    $sql  = "SELECT * FROM album ORDER BY AlbumID DESC";
			    $result = mysqli_query($conn, $sql); 

			    // print_r($result);
		   
			    echo'<table width="450" border="1">
						<tr>
							<th width="32"> <div align="center">ID </div></th>
							<th width="117"> <div align="center">Album Shot </div></th>
							<th width="104"> <div align="center">Album Name</div></th>
							<th width="60"> <div align="center">Edit</div></th>
							<th width="84"> <div align="center">Gallery</div></th>
							<th width="62"> <div align="center">Delete</div></th>
						</tr>';
						
			while($row = mysqli_fetch_array($result))
			{
			// echo print_r($row); 
			echo'
					
					

						<tr>
						


						
							<td><div align="center">'.$row["AlbumID"].'</div> </td>
							<td><center><a href="'.base64_encode($row['AlbumShot'] ).'"target="_blank">                          
							<img src="data:image/jpeg;base64,'.base64_encode($row['AlbumShot'] ).'" height="100" width="100" class="img-thumnail" /></a></center></td>
							<td><center>'.$row["AlbumName"].'</center></td>
							<td><center><a href="edit_album.php?AlbumID='.$row["AlbumID"].'">Edit</a></center></td>
							<td><center><a href="upload_gallery.php ?AlbumID='.$row["AlbumID"].'"> Upload </a></center></td>
							<td><center><a href="delete_album.php?AlbumID='.$row["AlbumID"].'">Delete</a></center></td>
						</tr>
					


			'; 
			
			}

			echo '</table>';
		
	$conn->close();
	?>
 	</div>

    <div class="col-sm-3">
        <h3></h3>        
        
    </div>

  </div>
</div>

</body>
</html>