<?php
error_reporting(0)
?>

<!DOCTYPE html >
<html >
<head>
  <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <title>ประมวลผลโปรแกรมคำนวณการซื้อของร้านค้า</title>

</head>


<body>

      <div class="relative flex items-top justify-center min-h-screen bg-gray-100 dark:bg-gray-900 sm:items-center py-4 sm:pt-0">

        <div align="center">
           
           <h2>โปรแกรมคำนวณการซื้อของร้านค้า</h2>

		<?php

			$price = $_POST['price'];
			$store = 25;
			$store2 = 30;

			if (isset($store)){

				$item = floor($price / $store);     // 250/25=10 ชิ้น
				$rebate=$store - ($store*0.2);   	// 25-(25*0.2) = ชิ้นละ 20 บาท

				if ($item >=10) {
					$pay = $price-($rebate*$item);  // (250-(20*10)) = เหลือ 50 บาท
					$itempay=floor($pay/$store); 	// 50/25= ได้อีก 2 ชิ้น
					$item = $item+$itempay; 		// 10+2=12 รวมของที่ได้ 12 ชิ้น
					$totalpay = $price-($rebate*$item);
				}

				// $pay = (($store*$item)*0.2);  // ((25*10)*0.2) =50 บาท

				// $totalpay=floor($pay/$store); // 50/25=2 ชิ้น
				// $item = $item+$totalpay; // 10+2=12 รวมของที่ได้ 12 ชิ้น
				// $pricepay=$totalpay;
				// $pay2=($pay+$price)-($item*$store); // ((50+250)-(12*(25*0.2)))เงินที่เหลือ

				// echo "$item";
				echo "ซื้อร้านที่ 1 ได้ ".$item. " ชิ้น เหลือเงิน " .$totalpay. " บาท" ."<br>";

			}if (isset($store2)){
				$item2 = floor($price / $store2);    // 250/30=8 ชิ้น
				for ($i=3; $i <= $item2 ; $i+=3) { 
					if (isset($item2)) {
						$item3 = $item3 + 1;
					}
				}
				$totalitem=$item3+$item2;
				$pay2 = ($store2*$item2); 
				$total2 = $price - $pay2;  
				echo "ซื้อร้านที่ 2 ได้ ".$totalitem. " ชิ้น เหลือเงิน " .$total2. " บาท" ."<br>";
			}

			if($item > $totalitem && $pay2 > $total2){
				echo "แนะนำให้ซื้อร้านที่ 1 จะคุ้มที่สุด" ;
			}elseif ($totalitem > $item) {
				echo "แนะนำให้ซื้อร้านที่ 2 จะคุ้มที่สุด";
			}elseif ($item == $totalitem && $pay2 > $total2){
				echo "แนะนำให้ซื้อร้านที่ 1 จะคุ้มที่สุด" ;

			}

		?>
         
        </div>
       </div> 
</body>
</html>
